# Instruções para Publicar a Landing Page - Grupo Altros

## Arquivos Necessários

Todos estes arquivos devem estar na **mesma pasta**:

1. **landing_page_grupo_altros.html** - Arquivo principal da LP
2. **logo-grupo-altros.jpg** - Logo do Grupo Altros (para o header)
3. **p5.jpg** - Foto de Patricia para a seção hero (topo)
4. **pati1.jpg** - Foto de Patricia para a seção "Quem é Patricia"

## Passo a Passo para Publicar

### Opção 1: Netlify (Recomendado - Grátis e Fácil)

1. Acesse: https://www.netlify.com/
2. Clique em "Sign up"
3. Crie uma conta com GitHub, Google ou email
4. Clique em "New site from Git" ou "Drag and drop"
5. **Se arrastar e soltar:** Selecione todos os 4 arquivos listados acima
6. Pronto! Sua LP estará online em segundos

### Opção 2: Vercel (Grátis)

1. Acesse: https://vercel.com/
2. Clique em "Sign Up"
3. Crie uma conta
4. Clique em "New Project"
5. Faça upload dos 4 arquivos
6. Clique em "Deploy"

### Opção 3: GitHub Pages (Grátis)

1. Crie uma conta em https://github.com/
2. Crie um novo repositório chamado "grupo-altros-lp"
3. Faça upload dos 4 arquivos
4. Vá em Settings > Pages
5. Selecione "main" como branch
6. Sua LP estará em: https://seu-usuario.github.io/grupo-altros-lp/

### Opção 4: Seu Próprio Servidor/Hospedagem

1. Acesse o painel de controle da sua hospedagem
2. Faça upload dos 4 arquivos via FTP ou File Manager
3. Certifique-se que todos estão na mesma pasta
4. Acesse via seu domínio

## Verificação

Após publicar, verifique se:
- ✅ Logo aparece no header
- ✅ Foto de Patricia aparece no topo (hero section)
- ✅ Foto de Patricia aparece na seção "Quem é Patricia"
- ✅ Botões de WhatsApp funcionam
- ✅ Links do formulário funcionam
- ✅ Página é responsiva no mobile

## Dúvidas?

Se as imagens não aparecerem:
1. Verifique se todos os 4 arquivos estão na mesma pasta
2. Verifique se os nomes dos arquivos estão EXATAMENTE como listado acima
3. Limpe o cache do navegador (Ctrl+Shift+Delete)
4. Tente em outro navegador

## Próximos Passos

1. Compartilhe o link em redes sociais
2. Coloque em grupos de WhatsApp
3. Envie por email para seus contatos
4. Faça anúncios pagos (Google Ads, Facebook Ads)
5. Acompanhe conversões

Boa sorte! 🚀
